# StudyUp

This version supports Vercel.

## Vercel setup

The frontend already calls:

```js
fetch("/api/chat", { method: "POST", ... })
```

Vercel will run `api/chat.js` as the backend API route.

### Add your API key on Vercel

1. Go to your Vercel project.
2. Open **Settings**.
3. Open **Environment Variables**.
4. Add:
   - Name: `OPENAI_API_KEY`
   - Value: your OpenAI API key
   - Environment: Production, Preview, and Development if you want all of them
5. Redeploy your project after adding the variable.

Optional variable:

```text
OPENAI_MODEL=gpt-5-mini
```

## Local testing with Vercel CLI

```bash
vercel dev
```

Or run the included local server:

Windows PowerShell:

```powershell
$env:OPENAI_API_KEY="your_api_key_here"
node server.js
```

macOS / Linux:

```bash
export OPENAI_API_KEY="your_api_key_here"
node server.js
```

Then open:

```text
http://127.0.0.1:4173
```

## Important

Do not put your API key inside `src/app.js` or `index.html`. Browser files are visible to users. Keep the key only in Vercel Environment Variables or local environment variables.
