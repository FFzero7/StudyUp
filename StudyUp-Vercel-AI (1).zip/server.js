const http = require("http");
const fs = require("fs");
const path = require("path");

const root = __dirname;
const types = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".svg": "image/svg+xml"
};

const OPENAI_MODEL = process.env.OPENAI_MODEL || "gpt-5-mini";

const readJsonBody = (req) => new Promise((resolve, reject) => {
  let body = "";
  req.on("data", (chunk) => {
    body += chunk;
    if (body.length > 1_000_000) {
      req.destroy();
      reject(new Error("Request body too large"));
    }
  });
  req.on("end", () => {
    try {
      resolve(body ? JSON.parse(body) : {});
    } catch {
      reject(new Error("Invalid JSON"));
    }
  });
  req.on("error", reject);
});

const sendJson = (res, status, payload) => {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(payload));
};

const chatWithOpenAI = async ({ message, history = [], attachmentName = "" }) => {
  if (!process.env.OPENAI_API_KEY) {
    throw new Error("OPENAI_API_KEY is missing. Set it before starting the server.");
  }

  const recentHistory = history
    .slice(-10)
    .filter((item) => item && item.text && item.role)
    .map((item) => ({
      role: item.role === "bot" ? "assistant" : "user",
      content: String(item.text).slice(0, 1200)
    }));

  const input = [
    {
      role: "system",
      content:
        "You are StudyUp AI, a friendly homework helper for students. " +
        "Teach step by step instead of just giving final answers. " +
        "Keep answers short, clear, age-appropriate, and in the same language as the student. " +
        "For math, show the next step and ask the student to try the following step. " +
        "If a student asks for cheating, write a helpful explanation instead of doing dishonest work."
    },
    ...recentHistory,
    {
      role: "user",
      content: attachmentName
        ? `${message || "I uploaded a homework photo."}\nAttachment filename: ${attachmentName}\nNote: The current app only sends the filename, not the image content.`
        : message
    }
  ];

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`
    },
    body: JSON.stringify({
      model: OPENAI_MODEL,
      input,
      max_output_tokens: 450
    })
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`OpenAI API error ${response.status}: ${errorText.slice(0, 500)}`);
  }

  const data = await response.json();
  const textOutput = data.output_text || (data.output || [])
    .flatMap((item) => item.content || [])
    .filter((part) => part.type === "output_text" || part.type === "text")
    .map((part) => part.text)
    .join("\n")
    .trim();

  return textOutput || "Ich konnte gerade keine Antwort erstellen.";
};

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://127.0.0.1:4173");

  if (req.method === "POST" && url.pathname === "/api/chat") {
    try {
      const body = await readJsonBody(req);
      const message = String(body.message || "").trim();
      const attachmentName = String(body.attachmentName || "").trim();
      if (!message && !attachmentName) {
        sendJson(res, 400, { error: "Message is required." });
        return;
      }

      const answer = await chatWithOpenAI({
        message,
        attachmentName,
        history: Array.isArray(body.history) ? body.history : []
      });

      sendJson(res, 200, { answer });
    } catch (error) {
      console.error(error);
      sendJson(res, 500, { error: error.message || "AI request failed." });
    }
    return;
  }

  if (req.method !== "GET") {
    res.writeHead(405);
    res.end("Method not allowed");
    return;
  }

  const requestedPath = url.pathname === "/" ? "index.html" : url.pathname.slice(1);
  const filePath = path.normalize(path.join(root, requestedPath));

  if (!filePath.startsWith(root)) {
    res.writeHead(403);
    res.end("Forbidden");
    return;
  }

  fs.readFile(filePath, (error, data) => {
    if (error) {
      res.writeHead(404);
      res.end("Not found");
      return;
    }

    res.writeHead(200, { "Content-Type": types[path.extname(filePath)] || "text/plain; charset=utf-8" });
    res.end(data);
  });
});

server.listen(4173, "127.0.0.1", () => {
  console.log("StudyUp running at http://127.0.0.1:4173");
  console.log(`AI model: ${OPENAI_MODEL}`);
});
