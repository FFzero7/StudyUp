const OPENAI_MODEL = process.env.OPENAI_MODEL || "gpt-5-mini";

async function readJsonBody(req) {
  if (req.body && typeof req.body === "object") return req.body;
  if (typeof req.body === "string") return JSON.parse(req.body || "{}");

  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > 1_000_000) {
        reject(new Error("Request body too large"));
        req.destroy();
      }
    });
    req.on("end", () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch {
        reject(new Error("Invalid JSON"));
      }
    });
    req.on("error", reject);
  });
}

async function chatWithOpenAI({ message, history = [], attachmentName = "" }) {
  if (!process.env.OPENAI_API_KEY) {
    throw new Error("OPENAI_API_KEY is missing in Vercel Environment Variables.");
  }

  const recentHistory = history
    .slice(-10)
    .filter((item) => item && item.text && item.role)
    .map((item) => ({
      role: item.role === "bot" ? "assistant" : "user",
      content: String(item.text).slice(0, 1200)
    }));

  const input = [
    {
      role: "system",
      content:
        "You are StudyUp AI, a friendly homework helper for students. " +
        "Teach step by step instead of just giving final answers. " +
        "Keep answers short, clear, age-appropriate, and in the same language as the student. " +
        "For math, show the next step and ask the student to try the following step. " +
        "If a student asks for cheating, write a helpful explanation instead of doing dishonest work."
    },
    ...recentHistory,
    {
      role: "user",
      content: attachmentName
        ? `${message || "I uploaded a homework photo."}\nAttachment filename: ${attachmentName}\nNote: The current app only sends the filename, not the image content.`
        : message
    }
  ];

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`
    },
    body: JSON.stringify({
      model: OPENAI_MODEL,
      input,
      max_output_tokens: 450
    })
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`OpenAI API error ${response.status}: ${errorText.slice(0, 500)}`);
  }

  const data = await response.json();
  const textOutput = data.output_text || (data.output || [])
    .flatMap((item) => item.content || [])
    .filter((part) => part.type === "output_text" || part.type === "text")
    .map((part) => part.text)
    .join("\n")
    .trim();

  return textOutput || "Ich konnte gerade keine Antwort erstellen.";
}

module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    const body = await readJsonBody(req);
    const message = String(body.message || "").trim();
    const attachmentName = String(body.attachmentName || "").trim();

    if (!message && !attachmentName) {
      return res.status(400).json({ error: "Message is required." });
    }

    const answer = await chatWithOpenAI({
      message,
      attachmentName,
      history: Array.isArray(body.history) ? body.history : []
    });

    return res.status(200).json({ answer });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: error.message || "AI request failed." });
  }
};
